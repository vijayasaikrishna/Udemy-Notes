<?php echo 2+2;

$myname="Sai"; 
?>
<h1>This page is all about <?php echo $myname; ?></h1>

<?php echo 5*5 ;?>
<h2>All About <? php echo $myname; ?></h2>
