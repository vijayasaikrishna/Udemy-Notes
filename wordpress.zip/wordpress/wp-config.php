<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'MySQL' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ']--bpZ(dfvC_ZG5Pm[%BvV5-VO0nYndt2}QXyRFKVs3/KvJ#C{NDno2N.f)f0WWF' );
define( 'SECURE_AUTH_KEY',  ':o9[$a {C]. ZqH5wxGCzx;Aii`yp!K!1cm_/VAEsTJ/I.8P<&Wz&&Xz<2%_QeC:' );
define( 'LOGGED_IN_KEY',    'bw2&gPbWE!l=9a$1w6~JS9ma4]`7~|GC_J[Wuciq9K,y>^b1$[B-&q_p`,n&CJ?c' );
define( 'NONCE_KEY',        '~X*kOIg[FUJ:C*9<aL_pOxjINHeaBS-XmN,l3%MK*2Y:b 5SR2pJkPUV:oKs*9`h' );
define( 'AUTH_SALT',        'Fa}Dl3++d,A?1)o#ITlD[/WvPJ)j&FsZI?RFc&V!u2%$D):M-L-j6egGQRu7Hb@x' );
define( 'SECURE_AUTH_SALT', 'PmSK)]9El/.mi?od T@V{Ph^eA{3gPG T^ 8F4Bd?[f&#Dv-rD~rnSAp369Z;DIq' );
define( 'LOGGED_IN_SALT',   '$DaHJuEkMBf,.##ROXV|0IFgn.3?[g~KR/~I?10+2;8{?0t9tMSU6ajf0EoR,M=S' );
define( 'NONCE_SALT',       'Eyu@Mq~tb)2vT[v`ww`IWjN?GBzxRbUgNmYl;`b]hJuWhOZWmt8_[.>Hb$$_gye~' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_27';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
